﻿namespace DNS.Protocol.Marshalling {
    public enum Endianness {
        Big,
        Little,
    }
}
