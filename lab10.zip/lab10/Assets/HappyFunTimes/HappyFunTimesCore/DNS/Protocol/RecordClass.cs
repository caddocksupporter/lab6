﻿namespace DNS.Protocol {
    public enum RecordClass {
        IN = 1,
        ANY = 255,
    }
}
