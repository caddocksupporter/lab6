DNSTest
=======

This is a small script that runs the DNS server on port 4444 so it can
be tested without needed admin rights

