# Important!!

This example has to be created from scatch.

[In instructions on how to do that are at http://docs.happyfuntimes.net/docs/unity/3d-characters.html](http://docs.happyfuntimes.net/docs/unity/3d-characters.html).

