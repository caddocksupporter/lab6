# Multi-Machine Synced Clock Example

## NOTE: To really see this sample you need to build it and run
it outside of Unity.

See [http://docs.happyfuntimes.net/docs/unity/talking-between-games.html](http://docs.happyfuntimes.net/docs/unity/talking-between-games.html)
for details.

Also be sure to check out both the multi-machine example at `Assets/HappyFunTimes/MoreSamples/multi-machine/Scenes`
and the other synced clock example at `Assets/HappyFunTimes/MoreSamples/syncedclock/Scenes`


