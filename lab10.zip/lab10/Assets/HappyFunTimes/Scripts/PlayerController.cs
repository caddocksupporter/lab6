﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float speed = 4f;

    private HFTInput p1;
    private HFTGamepad p1_gamePad;

    private void Start()
    {
        p1 = GetComponent<HFTInput>();
        p1_gamePad = GetComponent<HFTGamepad>();

        Renderer renderer = GetComponent<Renderer>();
        renderer.material.color = p1_gamePad.color;
    }
    // Update is called once per frame
    void Update()
    {
        float dx = speed * (p1.GetAxis("Horizontal") + Input.GetAxis("Horizontal")) * Time.deltaTime;
        float dz = speed * (p1.GetAxis("Vectical") + Input.GetAxis("Vectical"))* Time.deltaTime;

        //move the players
        transform.position = transform.position + new Vector3(dx, 0f, dz);
    }
}