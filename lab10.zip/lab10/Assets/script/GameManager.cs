﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace HappyFunTimesExample
{
    public class GameManager : MonoBehaviour
    {
        public Text startButton;
        public GameObject Players;

        private void Awake()
        {
            Time.timeScale = 1f;
        }

        // Start is called before the first frame update
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {
            if (Timer.timeToStart <= 0)
            {
                startButton.gameObject.transform.parent.gameObject.SetActive(false);
                Players.SetActive(true);
                return;
            }

            startButton.text = "Start In " + Mathf.FloorToInt(Timer.timeToStart).ToString() + " sec.\n" +
                "Players: " + Players.transform.childCount;

            
                
        }
    }

}
