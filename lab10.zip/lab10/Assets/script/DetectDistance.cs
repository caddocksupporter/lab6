using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DetectDistance : MonoBehaviour
{
    public GameObject Target;
    public Text DistTextbox;
    public bool isSpecial;
    public int boolSpecial = 0;
    public Text SpecialIndicate;
    public GameObject comicText;


    void Awake()
    {
        Target = GameObject.Find("civkart");
        boolSpecial = 1;
        DistTextbox = GetComponent<Text>();
        SpecialIndicate = GetComponent<Text>();
    }
    
    void FixedUpdate()
    {
        float distance = Vector3.Distance(Target.transform.position, transform.position);

        if (distance < 5f & boolSpecial == 1)
        {
            comicText.SetActive(true);
            DistTextbox.text = "Nearest candidate is" + distance + " unit";
            boolSpecial = 1;
            SpecialIndicate.text = "Special is" + boolSpecial;
        }
        else
        {
            comicText.SetActive(false);
        }
    }
}
