﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class Hideiffar : MonoBehaviour
{
    GameObject player;
    public GameObject objToHide;


    void Start()
    {
        player = GameObject.Find("Player");

        var sFX = new GameObject("feetSFX");
        var source = sFX.AddComponent<AudioSource>();
    }

    // Update is called once per frame
    void Update()
    {

        float distance = Vector3.Distance(player.transform.position, transform.position);

        if (distance < 15f)
        {
            objToHide.SetActive(true);
        } else
        {
            objToHide.SetActive(false);
        }
    }
}