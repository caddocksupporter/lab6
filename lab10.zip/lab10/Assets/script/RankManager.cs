﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using HappyFunTimesExample;
using System.Linq;

namespace HappyFunTimesExample
{
    public class RankManager : MonoBehaviour
    {
        public class NetPlayers
        {
            public GameObject player;
            public GameObject score;
            public NetPlayers thisPlayer;
            public int playerScore;

            public NetPlayers(GameObject p, GameObject s)
            {
                player = p;
                score = s;
            }

            public void ShowPlayerDetail(NetPlayers p)
            {
                p.score.transform.GetChild(0).GetComponent<Text>().text =
                        p.player.GetComponent<ExampleSimplePlayer>().name + " ( " + p.player.GetComponent<ExampleSimplePlayer>().playerScore + " )";
            }
        }

        //public List<GameObject> netPlayers = new List<GameObject>();
        public List<NetPlayers> netPlayers = new List<NetPlayers>();

        public static RankManager instance;
        public GameObject ui;

        public Transform playerParent;

        // Start is called before the first frame update
        void Start()
        {
            instance = this;
            //netPlayers.Add
            if (instance.netPlayers.Count > 0)
            {
                print(instance.netPlayers.Count);
            }
            else
            {
                print("0");
            }
        }

        // Update is called once per frame
        void Update()
        {
            if (instance.netPlayers.Count > 0)
            {
                List<int> scores = new List<int>();

                foreach (NetPlayers r in netPlayers)
                {
                    // set player parents to Players
                    r.player.transform.SetParent(playerParent);

                    // update player scores
                    r.ShowPlayerDetail(r);
                        scores.Add(r.player.GetComponent<ExampleSimplePlayer>().playerScore);
                }

                var rank1 = scores.IndexOf(scores.Max());
                var numbers = scores.OrderByDescending(x => x).Skip(1).Take(2); // this will get collection of second and third highest element
                var rank2 = scores.FindIndex(x => x == numbers.First()); // will get second highest index
                var rank3 = scores.FindIndex(x => x == numbers.Last());
                netPlayers.ElementAt(rank1).score.transform.GetChild(0).GetComponent<Text>().text += " <Color=red># 1</Color>";
                netPlayers.ElementAt(rank2).score.transform.GetChild(0).GetComponent<Text>().text += " <Color=red># 2</Color>";
                netPlayers.ElementAt(rank3).score.transform.GetChild(0).GetComponent<Text>().text += " <Color=red># 3</Color>";



            }
        }
    }
}
