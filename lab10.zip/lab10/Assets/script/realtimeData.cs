﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class realtimeData : MonoBehaviour
{
    public Text TextBox;
    public GameObject Target;
    public static float distance;

    public void Awake()
    {
        TextBox = GetComponent<Text>();
        Target = GameObject.Find("Player");

        float distance = Vector3.Distance(Target.transform.position, transform.position);
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        TextBox.text = "Opponent waypoint:" + distance;
    }
}
